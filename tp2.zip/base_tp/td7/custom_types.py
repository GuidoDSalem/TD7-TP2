import typing 

Record = typing.Dict[str, typing.Any]
Records = typing.List[Record]